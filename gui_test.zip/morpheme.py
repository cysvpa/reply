"""
    텍스트 파일을 형태소 별로 분류하여 cvs파일 형식으로 제공하기
    입력 : txt파일
    출력 : 가중치를 고려한 단어(원형)
"""
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
from collections import Counter





#1. 정규화
def normalization(text):
    # 소문자와 대문자가 아닌 것은 공백으로 대체한다.
    letters_only = re.sub('[^a-zA-Z]', ' ', text)
    letters_only[:700]

    # 모두 소문자로 변환한다.
    lower_case = letters_only.lower()
    # 문자를 나눈다. => 토큰화
    normalized_words = lower_case.split()
    return normalized_words



#2. 불용어 제거
def stopword(normalized_words):
    stopwords.words('english')[:10]
    stopwords_words = [w for w in normalized_words if not w in stopwords.words('english')]
    return stopwords_words


#3. 스테밍 어간, 어미 분석기
def stemming(stopwords_words):
    stemmer = SnowballStemmer('english')
    stemmed_words = [stemmer.stem(w) for w in stopwords_words]
    return stemmed_words


#4 단어 빈도수 체크하기
def frequency_check(stemmed_words):
    frequency = Counter(stemmed_words).most_common()
    return frequency