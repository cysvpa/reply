import sys
from autoscroll_scraping import scrap
from parsing_html import *
from morpheme import *
from PyQt5.QtWidgets import *
from gui import my_widget
import naverPapagoNMT

class new_window(my_widget):
    def analysis(self):     #분석 버튼을 눌렀을때 실행할 메소드
        self.statusBar().showMessage(self.url_input.text())
        url = self.url_input.text()
        html = scrap(url)
        all_text = parse_comment(html)
        all_text = normalization(all_text)
        all_text = stopword(all_text)
        all_text = stemming(all_text)
        frequency = frequency_check(all_text) #결과 frequency는 (단어, 사용횟수) 튜플을 멤버로 가지는 리스트가 됨

        self.addition_test(3) #윈도우에 버튼을 추가하는 메소드(오류는 없으나 버튼이 추가되지 않는 상태)
    def addition_test(self,num):
        for a in range(0, num, 1):
            word = QPushButton('qweasd')
            word.resize(300,30)
            word.move(45, 120 + a * 50)
            word.setStyleSheet('background : white')

        #print(frequency)
        #self.addition_test(all_text)

app = QApplication(sys.argv)
window = new_window()
sys.exit(app.exec_())