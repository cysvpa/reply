from PyQt5.QtWidgets import *

class my_widget(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.url_and_comment()     #url 입력 박스가 포함된 스크롤 에리어
        self.translation()          #번역 내용을 포함하는 프레임
        self.statusBar()
        self.show()
        self.resize(1000,500)
        self.setStyleSheet('background: #DDDDDD')

    #위젯의 왼쪽에 해당하는 부분
    def url_and_comment(self):
        url_and_comments = QScrollArea(self)
        url_and_comments.resize(500, 500)
        url_and_comments.move(0, 0)
        url_and_comments.setStyleSheet('background: #DDDDDD')

        # URL 입력박스
        self.url_input = QLineEdit(url_and_comments)
        self.url_input.resize(300, 35)
        self.url_input.move(50, 50)
        self.url_input.setStyleSheet('color:black; background:white')  # color는 폰트의 색깔을 의미함

        # 댓글 분석 버튼
        url_analysis = QPushButton('분석', url_and_comments)
        url_analysis.resize(55, 40)
        url_analysis.move(360, 47)
        url_analysis.setStyleSheet('color:black; background:white')
        url_analysis.clicked.connect(self.analysis)

        #스크롤 바 생성(동작 안함)
        scroll_bar = QScrollBar(url_and_comments)
        scroll_bar.setOrientation(0)
        scroll_bar.move(479, 0)
        scroll_bar.resize(20, 500)

    #덧글 추가 메소드(반복문을 통해 자동생성 가능하도록 수정해야 함)
        '''
        def addition_test(num):
            for a in range(0, num, 1):
                word = QLabel('qweasd',url_and_comments)
                word.resize(word.sizeHint())
                word.move(45,120+a*50)
                word.setStyleSheet('background : white')
        '''

    def add_comments(self,frequency):
        num = 0
        for a in frequency:
            comment_btn = QLabel(a[0], self)
            comment_btn.resize(comment_btn.sizeHint())
            comment_btn.move(45, 120+num*50)
            comment_btn.setStyleSheet('background : white')

            comment_button = QPushButton('사전 검색', self)
            comment_button.resize(80, 29)
            comment_button.move(355, 118+num*50)

            num = num+1
            #comment_button.clicked.connect(self.dictionary())
        '''
        comment_label = QLabel(self)
        comment_label.resize(300,25)
        comment_label.move(45,170)
        comment_label.setStyleSheet('background : white')

        comment_button = QPushButton('사전 검색', self)
        comment_button.resize(80,29)
        comment_button.move(355, 118+50)
        '''

    #사전 내용 추가 메소드
    def dictionary(self):
        dic_label = QLabel('<b>사전 내용<b/>', self)
        dic_label.resize(500,250)
        dic_label.move(500,0)
        dic_label.setStyleSheet('background: white')

    #번역 내용 추가 메소드
    def translation(self):
        trans_label = QLabel('<b>번역 내용<b/>', self)
        trans_label.resize(500, 250)
        trans_label.move(500, 251)
        trans_label.setStyleSheet('background: #AAAAAA')


    def analysis(self):
        pass

    def dictionary(self):
        pass


